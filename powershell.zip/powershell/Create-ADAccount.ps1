<#
.SYNOPSIS
Creates an enabled Active Directory user in the configured demo OU.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$DemoOuDn,
    [Parameter(Mandatory = $true)][string]$FirstName,
    [Parameter(Mandatory = $true)][string]$LastName,
    [string]$MiddleName,
    [string]$LineManagerSam,
    [string]$Office,
    [string]$JobTitle,
    [string]$Department,
    [string]$Mobile,
    [string]$StaffId,
    [string]$TicketNumber,
    [string]$DateOfJoining,
    [string]$AccountType = 'Permanent',
    [string]$LastWorkingDay,
    [string]$ParentCompany,
    [string]$Subcompany
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($DemoOuDn)) {
    throw 'The configured demo OU is required.'
}
if ([string]::IsNullOrWhiteSpace($FirstName) -or [string]::IsNullOrWhiteSpace($LastName)) {
    throw 'First name and last name are required.'
}

Import-Module ActiveDirectory -ErrorAction Stop
Get-ADOrganizationalUnit -Identity $DemoOuDn -ErrorAction Stop | Out-Null

$baseSam = (($FirstName + '.' + $LastName) -replace '[^A-Za-z0-9._-]', '').Trim('.')
if ([string]::IsNullOrWhiteSpace($baseSam)) {
    throw 'The supplied name cannot produce a valid SamAccountName.'
}
$baseSam = $baseSam.Substring(0, [Math]::Min(20, $baseSam.Length))
$samAccountName = $baseSam
$suffix = 1
while (Get-ADUser -Filter "SamAccountName -eq '$samAccountName'" -SearchBase $DemoOuDn -SearchScope Subtree -ErrorAction Stop) {
    $suffixText = $suffix.ToString([Globalization.CultureInfo]::InvariantCulture)
    $prefixLength = 20 - $suffixText.Length
    if ($prefixLength -lt 1) {
        throw 'Could not generate an unused demo SamAccountName.'
    }
    $samAccountName = $baseSam.Substring(0, [Math]::Min($prefixLength, $baseSam.Length)) + $suffixText
    $suffix++
    if ($suffix -gt 1000) {
        throw 'Could not generate an unused demo SamAccountName.'
    }
}

$randomBytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try {
    $rng.GetBytes($randomBytes)
} finally {
    $rng.Dispose()
}
$initialPassword = [Convert]::ToBase64String($randomBytes) + 'aA1!'
$newUser = @{
    Name = "$FirstName $LastName"
    GivenName = $FirstName
    Surname = $LastName
    SamAccountName = $samAccountName
    Path = $DemoOuDn
    Enabled = $true
    AccountPassword = ConvertTo-SecureString $initialPassword -AsPlainText -Force
    ChangePasswordAtLogon = $true
}
if ($MiddleName) { $newUser['OtherAttributes'] = @{ initials = $MiddleName.Substring(0, 1) } }
if ($Office) { $newUser['Office'] = $Office }
if ($JobTitle) { $newUser['Title'] = $JobTitle }
if ($Department) { $newUser['Department'] = $Department }
if ($Mobile) { $newUser['MobilePhone'] = $Mobile }
if ($StaffId) { $newUser['EmployeeID'] = $StaffId }
if ($TicketNumber) { $newUser['Description'] = "Demo account; ticket $TicketNumber; joining $DateOfJoining" }
if ($ParentCompany) { $newUser['Company'] = $ParentCompany }
if ($Subcompany) { $newUser['Division'] = $Subcompany }
if ($LineManagerSam) {
    $manager = Get-ADUser -Identity $LineManagerSam -ErrorAction Stop
    $newUser['Manager'] = $manager.DistinguishedName
}

New-ADUser @newUser -ErrorAction Stop
if ($AccountType -ne 'Permanent' -and $LastWorkingDay) {
    Set-ADAccountExpiration -Identity $samAccountName -DateTime ([datetime]::Parse($LastWorkingDay)) -ErrorAction Stop
}

$created = Get-ADUser -Identity $samAccountName -Properties DistinguishedName, Enabled -ErrorAction Stop
$Ansible.Result = @{
    success = $true
    sam_account_name = $created.SamAccountName
    distinguished_name = $created.DistinguishedName
    enabled = $created.Enabled
    password_change_required = $true
}
