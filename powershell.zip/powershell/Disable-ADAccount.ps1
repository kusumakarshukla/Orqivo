<#
.SYNOPSIS
Disables an account only when it is inside the configured demo OU.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$DemoOuDn,
    [Parameter(Mandatory = $true)][string]$SamAccountName
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($DemoOuDn)) {
    throw 'The configured demo OU is required.'
}
if ($SamAccountName -notmatch '^[A-Za-z0-9._-]{1,20}$') {
    throw 'SamAccountName contains unsupported characters.'
}

Import-Module ActiveDirectory -ErrorAction Stop
Get-ADOrganizationalUnit -Identity $DemoOuDn -ErrorAction Stop | Out-Null

$user = Get-ADUser `
    -Filter "SamAccountName -eq '$SamAccountName'" `
    -SearchBase $DemoOuDn `
    -SearchScope Subtree `
    -Properties Enabled `
    -ErrorAction Stop
if (-not $user) {
    throw 'The requested account was not found inside the configured demo OU.'
}

if ($user.Enabled) {
    Disable-ADAccount -Identity $user -Confirm:$false -ErrorAction Stop
    $Ansible.Changed = $true
}

$verifiedUser = Get-ADUser -Identity $user.DistinguishedName -Properties Enabled -ErrorAction Stop
if ($verifiedUser.Enabled) {
    throw 'The account is still enabled after the disable operation.'
}

$Ansible.Result = @{
    success = $true
    sam_account_name = $verifiedUser.SamAccountName
    enabled = $verifiedUser.Enabled
}
